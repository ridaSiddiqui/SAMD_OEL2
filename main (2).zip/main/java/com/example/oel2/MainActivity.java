package com.example.oel2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {
    EditText name;
    EditText password;
    Button clk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Login(View view) {
        name = (EditText) findViewById(R.id.name);
        password = (EditText) findViewById(R.id.edtpwd);
        clk = (Button) findViewById(R.id.button);
        if (name.getText().toString().equals("rida") && password.getText().toString().equals("rida")) {
           Intent a = new Intent(MainActivity.this, Login.class);
           startActivity(a);

        } else {
            name.setError("Error! Something is not correct \n enter useremail and password correctly");
            password.setError("Error! Something is not correct \n enter useremail and password correctly");
        }

    }
}